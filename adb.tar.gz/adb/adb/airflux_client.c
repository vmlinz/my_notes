/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>

#include <cutils/sockets.h>	/* link to libcutils */

#include "sysdeps.h"
#include "airflux_client.h"
#include "airflux_server.h"

ADB_MUTEX_DEFINE( airflux_client_list_lock );

static short airflux_client_next_id = 0;
static struct airflux_client airflux_client_list = {
	.next = &airflux_client_list,
	.prev = &airflux_client_list,
};

struct airflux_client* airflux_find_client(short id)
{
	struct airflux_client *c, *r = NULL;

	adb_mutex_lock(&airflux_client_list_lock);
	for (c = airflux_client_list.next;
	     c != &airflux_client_list; c = c->next) {
		if (c->ac_id == id) {
			r = c;
			break;
		}
	}
	adb_mutex_unlock(&airflux_client_list_lock);

	return r;
}

/* lock the list first */
void airflux_insert_client(struct airflux_client *c,
			struct airflux_client *l)
{
	c->next       = l;
	c->prev       = c->next->prev;
	c->prev->next = c;
	c->next->prev = c;
}

void airflux_install_client(struct airflux_client *c)
{
	adb_mutex_lock(&airflux_client_list_lock);

	c->ac_id = airflux_client_next_id++;
	airflux_insert_client(c, &airflux_client_socket_list);

	adb_mutex_unlock(&airflux_client_list_lock);
}

struct airflux_client *airflux_create_client(int fd)
{
    struct airflux_client *c = calloc(1, sizeof(struct airflux_client));
    if (c == NULL) fatal("failed to allocate socket");
    airflux_install_client(c);

    s->fd = fd;
}

void airflux_remove_client(struct airflux_client *c)
{
	adb_mutex_lock(&airflux_client_list_lock);
	/* _lock_ should already be held */
	if (c->prev && c->next)
	{
		c->prev->next = c->next;
		c->next->prev = c->prev;
		c->next = 0;
		c->prev = 0;
		c->ac_id = 0;
		c->ac_fd = 0;
	}

	free(c);

	adb_mutex_unlock(&airflux_client_list_lock);
}

int airflux_connect(int fd, char *cmd)
{
	int fw_sock_fd = 0;
	int len;

	if (cmd == NULL)
	{
		return error;
	}

	fw_sock_fd = socket_loopback_client(AIRFLUX_FRAMEWORK_SERVER_PORT,
					SOCK_STREAM);

	len = send(fw_sock_fd, cmd, strlen(cmd), 0);

	if (len < 0)
	{
		snprintf(buf, BUFFER_SIZE, "error comes when send command to server %s!",command);
		goto clean;
	}

	length = recv(clifd, buf, BUFFER_SIZE, 0);

	if (length < 0)
		goto clean;

	error = 0;

clean:
	if(clifd != NULL)
		close(clifd);

	writex(fd, buf, strlen(buf));

	return error;
}
