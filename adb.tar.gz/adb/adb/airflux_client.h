#ifndef _AIRFLUX_CLIENT_H_
#define _AIRFLUX_CLIENT_H_

#define AIRFLUX_FRAMEWORK_SERVER_PORT 20000 /* framework space server port */
#define AIRFLUX_BUFFER_SIZE           255

/* airflux client socket types */
#define	SOCK_NONE          0x00
#define	SOCK_HTTP          0x01
#define	SOCK_FTP           0x02
#define	SOCK_UE_MANAGER    0x03
#define	SOCK_CS_CALL       0x04
#define	SOCK_VIDEO_CALL    0x05
#define	SOCK_TCP_DUMP      0x06
#define	SOCK_FILE          0x07
#define	SOCK_STREAM_MEDIA  0x08
#define	SOCK_MAX           0xff

struct airflux_client
{
	struct airflux_client *prev;
	struct airflux_client *next;

	short ac_id;		/* client packet ID */
	short ac_sock_type;	/* client socket type */
	int ac_sock_fd;		/* client socket fd */
};

int airflux_connect(int, char *);

#endif /* _AIRFLUX_CLIENT_H_ */
