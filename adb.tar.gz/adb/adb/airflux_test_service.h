int airflux_test(char *service);
