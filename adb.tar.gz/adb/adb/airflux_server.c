#include "airflux_server.h"
#include "airflux_client.h"

ADB_MUTEX_DEFINE( airflux_server_lock );

static int airflux_server_socket = 0;
static int airflux_server_status = 0;

/** airflux socket server thread function
 * @param none
 * @ret none
 */
static void airflux_server_thread_func(void)
{
}

/** get current airflux socket server status
 * @param none
 * @ret server running status, 0 for stopped, 1 for running
 */
int airflux_server_status()
{
}

/** set airflux_server_status to 0 to stop the server
 * @param none
 * @ret
 */
int airflux_server_stop()
{
}

/** create airflux server which run in a thread under adbd process
 * @param none
 * @ret result for server create, 0 for failing, 1 for success
 */
int airflux_server_create()
{
}
