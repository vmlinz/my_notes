/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

#include "fdevent.h"
#include "adb_client.h"
#include "airflux_test_service.h"

#if ADB_HOST
#define AIRFLUX_PREFIX "airflux_test:"

int airflux_test(char *service) {
	/*
	  if(!strncmp(service, "helloworld", sizeof("helloworld")) == 0) {
	  fprintf(stdout, "Oops: service \"%s\" is not suported in this version\n", service);
	  fprintf(stdout, "try \"adb airflux_test helloworld\"\nn");
	  return 1;
	  }
	*/
	char command[256];
	char buf[1024];

	fprintf(stdout, "airflux commands ++++++++++\n");
	snprintf(command, 256, "%s%s", AIRFLUX_PREFIX, service);
	int fd = adb_connect(command);
	if(fd < 0) {
		fprintf(stderr,"error: %s\n", adb_error());
		return 1;
	}


	int ret = readx(fd, buf, sizeof(buf));
	if (ret == 0) return 1;

	buf[ret] = 0;
	fprintf(stdout, "\nMessage From Remote:\n\t%s\n", buf);

	return 0;
}

#else

#include "airflux_client.h"

static void write_string(int fd, const char* str)
{
	writex(fd, str, strlen(str));
}

void airflux_test_service(int fd, void *cookie) {

	airflux_connect(fd, (char*)cookie);

	close(fd);
}

#endif //end ADB_HOST
